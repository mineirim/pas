create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.grupos_permissoes DROP CONSTRAINT pagina_grupos;
ALTER TABLE ONLY public.usuarios_grupos DROP CONSTRAINT fk_usuario_grupos;
ALTER TABLE ONLY public.projetos DROP CONSTRAINT fk_subprojeto_projeto_id;
ALTER TABLE ONLY public.programas DROP CONSTRAINT fk_situacoes_programas;
ALTER TABLE ONLY public.projetos DROP CONSTRAINT fk_projeto_programa;
ALTER TABLE ONLY public.programas DROP CONSTRAINT fk_programas_responsavel_id;
ALTER TABLE ONLY public.objetivos_projeto DROP CONSTRAINT fk_objetivosprojeto_projeto_id;
ALTER TABLE ONLY public.objetivos_programa DROP CONSTRAINT fk_objetivoprograma_programa_id;
ALTER TABLE ONLY public.metas_acao DROP CONSTRAINT fk_objetivo_meta;
ALTER TABLE ONLY public.estrategias_acao DROP CONSTRAINT fk_objetivo_estrategia;
ALTER TABLE ONLY public.metas_projeto DROP CONSTRAINT fk_metasprojeto_projeto_id;
ALTER TABLE ONLY public.metas_programa DROP CONSTRAINT fk_metasprograma_programa_id;
ALTER TABLE ONLY public.indicadores_programa DROP CONSTRAINT fk_indicadorprograma_programa_id;
ALTER TABLE ONLY public.indicadores_programa DROP CONSTRAINT fk_indicadorprograma_indicador_config_id;
ALTER TABLE ONLY public.indicadores_projeto DROP CONSTRAINT fk_indicador_projeto_projeto_id;
ALTER TABLE ONLY public.indicadores_projeto DROP CONSTRAINT fk_indicador_projeto_indicador_config_id;
ALTER TABLE ONLY public.indicador_config DROP CONSTRAINT fk_indicador_config_tipo_periodo_id;
ALTER TABLE ONLY public.indicador_config DROP CONSTRAINT fk_indicador_config_indicador_id;
ALTER TABLE ONLY public.usuarios_grupos DROP CONSTRAINT fk_grupo_usuarios;
ALTER TABLE ONLY public.grupos_permissoes DROP CONSTRAINT fk_grupo_paginas;
ALTER TABLE ONLY public.acoes DROP CONSTRAINT fk_acoes_projeto_id;
ALTER TABLE ONLY public.objetivos_acao DROP CONSTRAINT fk_acao_objetivo;
DROP INDEX public.usuarios_username_index;
DROP INDEX public.recursos_situacao_index;
DROP INDEX public.recursos_meta_id_index;
DROP INDEX public.projetos_situacao_index;
DROP INDEX public.projetos_programa_id_index;
DROP INDEX public.programas_responsavel_id_index;
DROP INDEX public.programas_alteracao_usuario_id_index;
DROP INDEX public.metas_situacao_index;
DROP INDEX public.metas_objetivo_id_index;
DROP INDEX public.estrategias_situacao_index;
DROP INDEX public.estrategias_objetivo_id_index;
DROP INDEX public.acoes_projeto_id_index;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT pk_usuarios_id;
ALTER TABLE ONLY public.usuarios_grupos DROP CONSTRAINT pk_users_roles_id;
ALTER TABLE ONLY public.tipo_periodo DROP CONSTRAINT pk_tipo_periodo_id;
ALTER TABLE ONLY public.situacoes DROP CONSTRAINT pk_situacao_id;
ALTER TABLE ONLY public.grupos DROP CONSTRAINT pk_roles_id;
ALTER TABLE ONLY public.recursos DROP CONSTRAINT pk_recursos_id;
ALTER TABLE ONLY public.projetos DROP CONSTRAINT pk_projeto_id;
ALTER TABLE ONLY public.programas DROP CONSTRAINT pk_programas_id;
ALTER TABLE ONLY public.paginas DROP CONSTRAINT pk_permissao_id;
ALTER TABLE ONLY public.parcerias_acao DROP CONSTRAINT pk_parceria_id;
ALTER TABLE ONLY public.objetivos_projeto DROP CONSTRAINT pk_objetivos_projeto_id;
ALTER TABLE ONLY public.objetivos_programa DROP CONSTRAINT pk_objetivos_programas_id;
ALTER TABLE ONLY public.objetivos_acao DROP CONSTRAINT pk_objetivos_id;
ALTER TABLE ONLY public.metas_projeto DROP CONSTRAINT pk_metas_projeto_id;
ALTER TABLE ONLY public.metas_programa DROP CONSTRAINT pk_meta_programas_id;
ALTER TABLE ONLY public.metas_acao DROP CONSTRAINT pk_meta_id;
ALTER TABLE ONLY public.indicadores_projeto DROP CONSTRAINT pk_indicadores_projeto_id;
ALTER TABLE ONLY public.indicadores_programa DROP CONSTRAINT pk_indicadores_programa_id;
ALTER TABLE ONLY public.indicadores DROP CONSTRAINT pk_indicador_id;
ALTER TABLE ONLY public.indicador_config DROP CONSTRAINT pk_indicador_configs_id;
ALTER TABLE ONLY public.grupos_permissoes DROP CONSTRAINT pk_grupo_permissao_id;
ALTER TABLE ONLY public.estrategias_acao DROP CONSTRAINT pk_estrategia_id;
ALTER TABLE ONLY public.acoes DROP CONSTRAINT pk_acao_id;
ALTER TABLE public.usuarios_grupos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tipo_periodo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.situacoes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.recursos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.projetos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.parcerias_acao ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.paginas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.objetivos_projeto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.objetivos_programa ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.objetivos_acao ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.metas_projeto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.metas_programa ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.metas_acao ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.indicadores_projeto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.indicadores_programa ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.indicadores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.indicador_config ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.grupos_permissoes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.grupos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.estrategias_acao ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.acoes ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.usuarios_id_seq;
DROP SEQUENCE public.usuarios_grupos_id_seq;
DROP TABLE public.usuarios_grupos;
DROP TABLE public.usuarios;
DROP SEQUENCE public.usuarios_id;
DROP SEQUENCE public.tipo_periodo_id_seq;
DROP TABLE public.tipo_periodo;
DROP SEQUENCE public.situacoes_id_seq;
DROP TABLE public.situacoes;
DROP SEQUENCE public.recursos_id_seq;
DROP TABLE public.recursos;
DROP SEQUENCE public.projetos_id_seq;
DROP TABLE public.projetos;
DROP SEQUENCE public.programas_id_seq;
DROP TABLE public.programas;
DROP SEQUENCE public.programas_id;
DROP SEQUENCE public.parcerias_acao_id_seq;
DROP TABLE public.parcerias_acao;
DROP SEQUENCE public.paginas_id_seq;
DROP TABLE public.paginas;
DROP SEQUENCE public.objetivos_projeto_id_seq;
DROP TABLE public.objetivos_projeto;
DROP SEQUENCE public.objetivos_programa_id_seq;
DROP TABLE public.objetivos_programa;
DROP SEQUENCE public.objetivos_acao_id_seq;
DROP TABLE public.objetivos_acao;
DROP SEQUENCE public.metas_projeto_id_seq;
DROP TABLE public.metas_projeto;
DROP SEQUENCE public.metas_programa_id_seq;
DROP TABLE public.metas_programa;
DROP SEQUENCE public.metas_acao_id_seq;
DROP TABLE public.metas_acao;
DROP SEQUENCE public.indicadores_projeto_id_seq;
DROP TABLE public.indicadores_projeto;
DROP SEQUENCE public.indicadores_programa_id_seq;
DROP TABLE public.indicadores_programa;
DROP SEQUENCE public.indicadores_id_seq;
DROP TABLE public.indicadores;
DROP SEQUENCE public.indicador_config_id_seq;
DROP TABLE public.indicador_config;
DROP SEQUENCE public.grupos_permissoes_id_seq;
DROP TABLE public.grupos_permissoes;
DROP SEQUENCE public.grupos_id_seq;
DROP TABLE public.grupos;
DROP SEQUENCE public.estrategias_acao_id_seq;
DROP TABLE public.estrategias_acao;
DROP SEQUENCE public.acoes_id_seq;
DROP TABLE public.acoes;
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: acoes; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE acoes (
    id integer NOT NULL,
    descricao character varying(200),
    recursos character varying(200),
    cronograma text,
    situacao_id smallint DEFAULT 1,
    projeto_id integer NOT NULL,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id integer NOT NULL
);


ALTER TABLE public.acoes OWNER TO dbmonitora;

--
-- Name: acoes_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE acoes_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.acoes_id_seq OWNER TO dbmonitora;

--
-- Name: acoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE acoes_id_seq OWNED BY acoes.id;


--
-- Name: acoes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('acoes_id_seq', 44, true);


--
-- Name: estrategias_acao; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE estrategias_acao (
    id integer NOT NULL,
    descricao character varying(200),
    situacao_id integer DEFAULT 1 NOT NULL,
    acao_id integer NOT NULL,
    objetivo_id integer,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id integer NOT NULL
);


ALTER TABLE public.estrategias_acao OWNER TO dbmonitora;

--
-- Name: TABLE estrategias_acao; Type: COMMENT; Schema: public; Owner: dbmonitora
--

COMMENT ON TABLE estrategias_acao IS 'as estratégias das ações estão vinculadas ao objetivo da acao';


--
-- Name: estrategias_acao_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE estrategias_acao_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.estrategias_acao_id_seq OWNER TO dbmonitora;

--
-- Name: estrategias_acao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE estrategias_acao_id_seq OWNED BY estrategias_acao.id;


--
-- Name: estrategias_acao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('estrategias_acao_id_seq', 33, true);


--
-- Name: grupos; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE grupos (
    id integer NOT NULL,
    grupo character varying(50) NOT NULL,
    descricao character varying(200) NOT NULL
);


ALTER TABLE public.grupos OWNER TO dbmonitora;

--
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE grupos_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.grupos_id_seq OWNER TO dbmonitora;

--
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE grupos_id_seq OWNED BY grupos.id;


--
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('grupos_id_seq', 19, true);


--
-- Name: grupos_permissoes; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE grupos_permissoes (
    id integer NOT NULL,
    grupo_id integer NOT NULL,
    pagina_id integer
);


ALTER TABLE public.grupos_permissoes OWNER TO dbmonitora;

--
-- Name: grupos_permissoes_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE grupos_permissoes_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.grupos_permissoes_id_seq OWNER TO dbmonitora;

--
-- Name: grupos_permissoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE grupos_permissoes_id_seq OWNED BY grupos_permissoes.id;


--
-- Name: grupos_permissoes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('grupos_permissoes_id_seq', 47, true);


--
-- Name: indicador_config; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE indicador_config (
    id integer NOT NULL,
    indicador_id integer NOT NULL,
    tipo_periodo_id integer NOT NULL
);


ALTER TABLE public.indicador_config OWNER TO dbmonitora;

--
-- Name: indicador_config_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE indicador_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.indicador_config_id_seq OWNER TO dbmonitora;

--
-- Name: indicador_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE indicador_config_id_seq OWNED BY indicador_config.id;


--
-- Name: indicador_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('indicador_config_id_seq', 1, false);


--
-- Name: indicadores; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE indicadores (
    id integer NOT NULL,
    descricao character varying NOT NULL,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id integer NOT NULL
);


ALTER TABLE public.indicadores OWNER TO dbmonitora;

--
-- Name: indicadores_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE indicadores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.indicadores_id_seq OWNER TO dbmonitora;

--
-- Name: indicadores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE indicadores_id_seq OWNED BY indicadores.id;


--
-- Name: indicadores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('indicadores_id_seq', 1, false);


--
-- Name: indicadores_programa; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE indicadores_programa (
    id integer NOT NULL,
    programa_id integer NOT NULL,
    indicador_config_id integer NOT NULL
);


ALTER TABLE public.indicadores_programa OWNER TO dbmonitora;

--
-- Name: indicadores_programa_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE indicadores_programa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.indicadores_programa_id_seq OWNER TO dbmonitora;

--
-- Name: indicadores_programa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE indicadores_programa_id_seq OWNED BY indicadores_programa.id;


--
-- Name: indicadores_programa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('indicadores_programa_id_seq', 1, false);


--
-- Name: indicadores_projeto; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE indicadores_projeto (
    id integer NOT NULL,
    projeto_id integer NOT NULL,
    indicador_config_id integer NOT NULL
);


ALTER TABLE public.indicadores_projeto OWNER TO dbmonitora;

--
-- Name: indicadores_projeto_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE indicadores_projeto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.indicadores_projeto_id_seq OWNER TO dbmonitora;

--
-- Name: indicadores_projeto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE indicadores_projeto_id_seq OWNED BY indicadores_projeto.id;


--
-- Name: indicadores_projeto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('indicadores_projeto_id_seq', 1, false);


--
-- Name: metas_acao; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE metas_acao (
    id integer NOT NULL,
    descricao character varying(200),
    situacao_id integer DEFAULT 1 NOT NULL,
    acao_id integer NOT NULL,
    objetivo_id integer,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id integer NOT NULL
);


ALTER TABLE public.metas_acao OWNER TO dbmonitora;

--
-- Name: metas_acao_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE metas_acao_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.metas_acao_id_seq OWNER TO dbmonitora;

--
-- Name: metas_acao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE metas_acao_id_seq OWNED BY metas_acao.id;


--
-- Name: metas_acao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('metas_acao_id_seq', 15, true);


--
-- Name: metas_programa; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE metas_programa (
    id integer NOT NULL,
    descricao character varying NOT NULL,
    programa_id integer NOT NULL
);


ALTER TABLE public.metas_programa OWNER TO dbmonitora;

--
-- Name: metas_programa_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE metas_programa_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.metas_programa_id_seq OWNER TO dbmonitora;

--
-- Name: metas_programa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE metas_programa_id_seq OWNED BY metas_programa.id;


--
-- Name: metas_programa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('metas_programa_id_seq', 14, true);


--
-- Name: metas_projeto; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE metas_projeto (
    id integer NOT NULL,
    descricao character varying NOT NULL,
    projeto_id integer NOT NULL
);


ALTER TABLE public.metas_projeto OWNER TO dbmonitora;

--
-- Name: metas_projeto_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE metas_projeto_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.metas_projeto_id_seq OWNER TO dbmonitora;

--
-- Name: metas_projeto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE metas_projeto_id_seq OWNED BY metas_projeto.id;


--
-- Name: metas_projeto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('metas_projeto_id_seq', 17, true);


--
-- Name: objetivos_acao; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE objetivos_acao (
    id integer NOT NULL,
    descricao character varying(200),
    situacao_id smallint DEFAULT 1 NOT NULL,
    acao_id integer NOT NULL,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id integer NOT NULL
);


ALTER TABLE public.objetivos_acao OWNER TO dbmonitora;

--
-- Name: objetivos_acao_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE objetivos_acao_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.objetivos_acao_id_seq OWNER TO dbmonitora;

--
-- Name: objetivos_acao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE objetivos_acao_id_seq OWNED BY objetivos_acao.id;


--
-- Name: objetivos_acao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('objetivos_acao_id_seq', 130, true);


--
-- Name: objetivos_programa; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE objetivos_programa (
    id integer NOT NULL,
    descricao character varying DEFAULT 500 NOT NULL,
    programa_id integer NOT NULL
);


ALTER TABLE public.objetivos_programa OWNER TO dbmonitora;

--
-- Name: objetivos_programa_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE objetivos_programa_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.objetivos_programa_id_seq OWNER TO dbmonitora;

--
-- Name: objetivos_programa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE objetivos_programa_id_seq OWNED BY objetivos_programa.id;


--
-- Name: objetivos_programa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('objetivos_programa_id_seq', 7, true);


--
-- Name: objetivos_projeto; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE objetivos_projeto (
    id integer NOT NULL,
    descricao character varying NOT NULL,
    projeto_id integer NOT NULL
);


ALTER TABLE public.objetivos_projeto OWNER TO dbmonitora;

--
-- Name: objetivos_projeto_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE objetivos_projeto_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.objetivos_projeto_id_seq OWNER TO dbmonitora;

--
-- Name: objetivos_projeto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE objetivos_projeto_id_seq OWNED BY objetivos_projeto.id;


--
-- Name: objetivos_projeto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('objetivos_projeto_id_seq', 18, true);


--
-- Name: paginas; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE paginas (
    id integer NOT NULL,
    descricao character varying(100) NOT NULL,
    pagina character varying(200) NOT NULL,
    acao character varying
);


ALTER TABLE public.paginas OWNER TO dbmonitora;

--
-- Name: paginas_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE paginas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.paginas_id_seq OWNER TO dbmonitora;

--
-- Name: paginas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE paginas_id_seq OWNED BY paginas.id;


--
-- Name: paginas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('paginas_id_seq', 11, true);


--
-- Name: parcerias_acao; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE parcerias_acao (
    id integer NOT NULL,
    descricao character varying(200),
    situacao_id smallint DEFAULT 1 NOT NULL,
    acao_id integer NOT NULL,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id integer NOT NULL
);


ALTER TABLE public.parcerias_acao OWNER TO dbmonitora;

--
-- Name: parcerias_acao_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE parcerias_acao_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.parcerias_acao_id_seq OWNER TO dbmonitora;

--
-- Name: parcerias_acao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE parcerias_acao_id_seq OWNED BY parcerias_acao.id;


--
-- Name: parcerias_acao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('parcerias_acao_id_seq', 7, true);


--
-- Name: programas_id; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE programas_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.programas_id OWNER TO dbmonitora;

--
-- Name: programas_id; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('programas_id', 1, false);


--
-- Name: programas; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE programas (
    id integer DEFAULT nextval('programas_id'::regclass) NOT NULL,
    descricao character varying(500) NOT NULL,
    interfaces character varying(200) NOT NULL,
    situacao_id smallint DEFAULT 1 NOT NULL,
    responsavel_id integer NOT NULL,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id integer NOT NULL,
    menu character varying(20)
);


ALTER TABLE public.programas OWNER TO dbmonitora;

--
-- Name: programas_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE programas_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.programas_id_seq OWNER TO dbmonitora;

--
-- Name: programas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE programas_id_seq OWNED BY programas.id;


--
-- Name: programas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('programas_id_seq', 25, true);


--
-- Name: projetos; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE projetos (
    id integer NOT NULL,
    descricao character varying,
    interfaces character varying(200),
    situacao_id smallint DEFAULT 1 NOT NULL,
    programa_id integer,
    responsavel_id integer NOT NULL,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id integer NOT NULL,
    menu character varying(20),
    projeto_id integer
);


ALTER TABLE public.projetos OWNER TO dbmonitora;

--
-- Name: projetos_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE projetos_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.projetos_id_seq OWNER TO dbmonitora;

--
-- Name: projetos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE projetos_id_seq OWNED BY projetos.id;


--
-- Name: projetos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('projetos_id_seq', 20, true);


--
-- Name: recursos; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE recursos (
    id integer NOT NULL,
    fonte character varying(200),
    valor double precision,
    destino character varying(200),
    situacao smallint,
    meta_id integer NOT NULL,
    inclusao_data timestamp without time zone DEFAULT now() NOT NULL,
    inclusao_usuario_id integer NOT NULL,
    alteracao_data timestamp without time zone DEFAULT now() NOT NULL,
    alteracao_usuario_id timestamp without time zone NOT NULL
);


ALTER TABLE public.recursos OWNER TO dbmonitora;

--
-- Name: recursos_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE recursos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.recursos_id_seq OWNER TO dbmonitora;

--
-- Name: recursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE recursos_id_seq OWNED BY recursos.id;


--
-- Name: recursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('recursos_id_seq', 1, false);


--
-- Name: situacoes; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE situacoes (
    id integer NOT NULL,
    descricao character varying(50) NOT NULL
);


ALTER TABLE public.situacoes OWNER TO dbmonitora;

--
-- Name: situacoes_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE situacoes_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.situacoes_id_seq OWNER TO dbmonitora;

--
-- Name: situacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE situacoes_id_seq OWNED BY situacoes.id;


--
-- Name: situacoes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('situacoes_id_seq', 2, true);


--
-- Name: tipo_periodo; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE tipo_periodo (
    id integer NOT NULL,
    periodo character varying NOT NULL,
    descricao character varying NOT NULL
);


ALTER TABLE public.tipo_periodo OWNER TO dbmonitora;

--
-- Name: tipo_periodo_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE tipo_periodo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tipo_periodo_id_seq OWNER TO dbmonitora;

--
-- Name: tipo_periodo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE tipo_periodo_id_seq OWNED BY tipo_periodo.id;


--
-- Name: tipo_periodo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('tipo_periodo_id_seq', 1, false);


--
-- Name: usuarios_id; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE usuarios_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id OWNER TO dbmonitora;

--
-- Name: usuarios_id; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('usuarios_id', 1, false);


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE usuarios (
    id integer DEFAULT nextval('usuarios_id'::regclass) NOT NULL,
    nome character varying NOT NULL,
    username character varying(30) NOT NULL,
    password character varying(64) NOT NULL,
    email character varying(100) NOT NULL,
    situacao smallint DEFAULT 1 NOT NULL,
    salt character varying
);


ALTER TABLE public.usuarios OWNER TO dbmonitora;

--
-- Name: usuarios_grupos; Type: TABLE; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE TABLE usuarios_grupos (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    grupo_id integer NOT NULL
);


ALTER TABLE public.usuarios_grupos OWNER TO dbmonitora;

--
-- Name: usuarios_grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE usuarios_grupos_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.usuarios_grupos_id_seq OWNER TO dbmonitora;

--
-- Name: usuarios_grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE usuarios_grupos_id_seq OWNED BY usuarios_grupos.id;


--
-- Name: usuarios_grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('usuarios_grupos_id_seq', 49, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: dbmonitora
--

CREATE SEQUENCE usuarios_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO dbmonitora;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbmonitora
--

ALTER SEQUENCE usuarios_id_seq OWNED BY usuarios.id;


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbmonitora
--

SELECT pg_catalog.setval('usuarios_id_seq', 22, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE acoes ALTER COLUMN id SET DEFAULT nextval('acoes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE estrategias_acao ALTER COLUMN id SET DEFAULT nextval('estrategias_acao_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE grupos ALTER COLUMN id SET DEFAULT nextval('grupos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE grupos_permissoes ALTER COLUMN id SET DEFAULT nextval('grupos_permissoes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE indicador_config ALTER COLUMN id SET DEFAULT nextval('indicador_config_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE indicadores ALTER COLUMN id SET DEFAULT nextval('indicadores_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE indicadores_programa ALTER COLUMN id SET DEFAULT nextval('indicadores_programa_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE indicadores_projeto ALTER COLUMN id SET DEFAULT nextval('indicadores_projeto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE metas_acao ALTER COLUMN id SET DEFAULT nextval('metas_acao_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE metas_programa ALTER COLUMN id SET DEFAULT nextval('metas_programa_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE metas_projeto ALTER COLUMN id SET DEFAULT nextval('metas_projeto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE objetivos_acao ALTER COLUMN id SET DEFAULT nextval('objetivos_acao_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE objetivos_programa ALTER COLUMN id SET DEFAULT nextval('objetivos_programa_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE objetivos_projeto ALTER COLUMN id SET DEFAULT nextval('objetivos_projeto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE paginas ALTER COLUMN id SET DEFAULT nextval('paginas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE parcerias_acao ALTER COLUMN id SET DEFAULT nextval('parcerias_acao_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE projetos ALTER COLUMN id SET DEFAULT nextval('projetos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE recursos ALTER COLUMN id SET DEFAULT nextval('recursos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE situacoes ALTER COLUMN id SET DEFAULT nextval('situacoes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE tipo_periodo ALTER COLUMN id SET DEFAULT nextval('tipo_periodo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dbmonitora
--

ALTER TABLE usuarios_grupos ALTER COLUMN id SET DEFAULT nextval('usuarios_grupos_id_seq'::regclass);


--
-- Data for Name: acoes; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: estrategias_acao; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: grupos; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: grupos_permissoes; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: indicador_config; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: indicadores; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: indicadores_programa; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: indicadores_projeto; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: metas_acao; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: metas_programa; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: metas_projeto; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: objetivos_acao; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: objetivos_programa; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: objetivos_projeto; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: paginas; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: parcerias_acao; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: programas; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: projetos; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: recursos; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: situacoes; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: tipo_periodo; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Data for Name: usuarios_grupos; Type: TABLE DATA; Schema: public; Owner: dbmonitora
--

--
-- Name: pk_acao_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY acoes
    ADD CONSTRAINT pk_acao_id PRIMARY KEY (id);


--
-- Name: pk_estrategia_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY estrategias_acao
    ADD CONSTRAINT pk_estrategia_id PRIMARY KEY (id);


--
-- Name: pk_grupo_permissao_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY grupos_permissoes
    ADD CONSTRAINT pk_grupo_permissao_id PRIMARY KEY (id);


--
-- Name: pk_indicador_configs_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY indicador_config
    ADD CONSTRAINT pk_indicador_configs_id PRIMARY KEY (id);


--
-- Name: pk_indicador_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY indicadores
    ADD CONSTRAINT pk_indicador_id PRIMARY KEY (id);


--
-- Name: pk_indicadores_programa_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY indicadores_programa
    ADD CONSTRAINT pk_indicadores_programa_id PRIMARY KEY (id);


--
-- Name: pk_indicadores_projeto_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY indicadores_projeto
    ADD CONSTRAINT pk_indicadores_projeto_id PRIMARY KEY (id);


--
-- Name: pk_meta_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY metas_acao
    ADD CONSTRAINT pk_meta_id PRIMARY KEY (id);


--
-- Name: pk_meta_programas_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY metas_programa
    ADD CONSTRAINT pk_meta_programas_id PRIMARY KEY (id);


--
-- Name: pk_metas_projeto_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY metas_projeto
    ADD CONSTRAINT pk_metas_projeto_id PRIMARY KEY (id);


--
-- Name: pk_objetivos_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY objetivos_acao
    ADD CONSTRAINT pk_objetivos_id PRIMARY KEY (id);


--
-- Name: pk_objetivos_programas_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY objetivos_programa
    ADD CONSTRAINT pk_objetivos_programas_id PRIMARY KEY (id);


--
-- Name: pk_objetivos_projeto_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY objetivos_projeto
    ADD CONSTRAINT pk_objetivos_projeto_id PRIMARY KEY (id);


--
-- Name: pk_parceria_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY parcerias_acao
    ADD CONSTRAINT pk_parceria_id PRIMARY KEY (id);


--
-- Name: pk_permissao_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY paginas
    ADD CONSTRAINT pk_permissao_id PRIMARY KEY (id);


--
-- Name: pk_programas_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY programas
    ADD CONSTRAINT pk_programas_id PRIMARY KEY (id);


--
-- Name: pk_projeto_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY projetos
    ADD CONSTRAINT pk_projeto_id PRIMARY KEY (id);


--
-- Name: pk_recursos_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY recursos
    ADD CONSTRAINT pk_recursos_id PRIMARY KEY (id);


--
-- Name: pk_roles_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY grupos
    ADD CONSTRAINT pk_roles_id PRIMARY KEY (id);


--
-- Name: pk_situacao_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY situacoes
    ADD CONSTRAINT pk_situacao_id PRIMARY KEY (id);


--
-- Name: pk_tipo_periodo_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY tipo_periodo
    ADD CONSTRAINT pk_tipo_periodo_id PRIMARY KEY (id);


--
-- Name: pk_users_roles_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY usuarios_grupos
    ADD CONSTRAINT pk_users_roles_id PRIMARY KEY (id);


--
-- Name: pk_usuarios_id; Type: CONSTRAINT; Schema: public; Owner: dbmonitora; Tablespace: 
--

ALTER TABLE ONLY usuarios
    ADD CONSTRAINT pk_usuarios_id PRIMARY KEY (id);


--
-- Name: acoes_projeto_id_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX acoes_projeto_id_index ON acoes USING btree (projeto_id);


--
-- Name: estrategias_objetivo_id_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX estrategias_objetivo_id_index ON estrategias_acao USING btree (objetivo_id);


--
-- Name: estrategias_situacao_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX estrategias_situacao_index ON estrategias_acao USING btree (situacao_id);


--
-- Name: metas_objetivo_id_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX metas_objetivo_id_index ON metas_acao USING btree (objetivo_id);


--
-- Name: metas_situacao_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX metas_situacao_index ON metas_acao USING btree (situacao_id);


--
-- Name: programas_alteracao_usuario_id_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX programas_alteracao_usuario_id_index ON programas USING btree (alteracao_usuario_id);


--
-- Name: programas_responsavel_id_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX programas_responsavel_id_index ON programas USING btree (responsavel_id);


--
-- Name: projetos_programa_id_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX projetos_programa_id_index ON projetos USING btree (programa_id);


--
-- Name: projetos_situacao_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX projetos_situacao_index ON projetos USING btree (situacao_id);


--
-- Name: recursos_meta_id_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX recursos_meta_id_index ON recursos USING btree (meta_id);


--
-- Name: recursos_situacao_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX recursos_situacao_index ON recursos USING btree (situacao);


--
-- Name: usuarios_username_index; Type: INDEX; Schema: public; Owner: dbmonitora; Tablespace: 
--

CREATE INDEX usuarios_username_index ON usuarios USING btree (username);


--
-- Name: fk_acao_objetivo; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY objetivos_acao
    ADD CONSTRAINT fk_acao_objetivo FOREIGN KEY (acao_id) REFERENCES acoes(id);


--
-- Name: fk_acoes_projeto_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY acoes
    ADD CONSTRAINT fk_acoes_projeto_id FOREIGN KEY (projeto_id) REFERENCES projetos(id);


--
-- Name: fk_grupo_paginas; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY grupos_permissoes
    ADD CONSTRAINT fk_grupo_paginas FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_grupo_usuarios; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY usuarios_grupos
    ADD CONSTRAINT fk_grupo_usuarios FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_indicador_config_indicador_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY indicador_config
    ADD CONSTRAINT fk_indicador_config_indicador_id FOREIGN KEY (indicador_id) REFERENCES indicadores(id);


--
-- Name: fk_indicador_config_tipo_periodo_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY indicador_config
    ADD CONSTRAINT fk_indicador_config_tipo_periodo_id FOREIGN KEY (tipo_periodo_id) REFERENCES tipo_periodo(id);


--
-- Name: fk_indicador_projeto_indicador_config_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY indicadores_projeto
    ADD CONSTRAINT fk_indicador_projeto_indicador_config_id FOREIGN KEY (indicador_config_id) REFERENCES indicador_config(id);


--
-- Name: fk_indicador_projeto_projeto_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY indicadores_projeto
    ADD CONSTRAINT fk_indicador_projeto_projeto_id FOREIGN KEY (projeto_id) REFERENCES projetos(id);


--
-- Name: fk_indicadorprograma_indicador_config_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY indicadores_programa
    ADD CONSTRAINT fk_indicadorprograma_indicador_config_id FOREIGN KEY (indicador_config_id) REFERENCES indicador_config(id);


--
-- Name: fk_indicadorprograma_programa_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY indicadores_programa
    ADD CONSTRAINT fk_indicadorprograma_programa_id FOREIGN KEY (programa_id) REFERENCES programas(id);


--
-- Name: fk_metasprograma_programa_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY metas_programa
    ADD CONSTRAINT fk_metasprograma_programa_id FOREIGN KEY (programa_id) REFERENCES programas(id) ON DELETE CASCADE;


--
-- Name: fk_metasprojeto_projeto_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY metas_projeto
    ADD CONSTRAINT fk_metasprojeto_projeto_id FOREIGN KEY (projeto_id) REFERENCES projetos(id) ON DELETE CASCADE;


--
-- Name: fk_objetivo_estrategia; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY estrategias_acao
    ADD CONSTRAINT fk_objetivo_estrategia FOREIGN KEY (objetivo_id) REFERENCES objetivos_acao(id);


--
-- Name: fk_objetivo_meta; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY metas_acao
    ADD CONSTRAINT fk_objetivo_meta FOREIGN KEY (objetivo_id) REFERENCES objetivos_acao(id);


--
-- Name: fk_objetivoprograma_programa_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY objetivos_programa
    ADD CONSTRAINT fk_objetivoprograma_programa_id FOREIGN KEY (programa_id) REFERENCES programas(id) ON DELETE CASCADE;


--
-- Name: fk_objetivosprojeto_projeto_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY objetivos_projeto
    ADD CONSTRAINT fk_objetivosprojeto_projeto_id FOREIGN KEY (projeto_id) REFERENCES projetos(id) ON DELETE CASCADE;


--
-- Name: fk_programas_responsavel_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY programas
    ADD CONSTRAINT fk_programas_responsavel_id FOREIGN KEY (responsavel_id) REFERENCES usuarios(id);


--
-- Name: fk_projeto_programa; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY projetos
    ADD CONSTRAINT fk_projeto_programa FOREIGN KEY (programa_id) REFERENCES programas(id);


--
-- Name: fk_situacoes_programas; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY programas
    ADD CONSTRAINT fk_situacoes_programas FOREIGN KEY (situacao_id) REFERENCES situacoes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fk_subprojeto_projeto_id; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY projetos
    ADD CONSTRAINT fk_subprojeto_projeto_id FOREIGN KEY (projeto_id) REFERENCES projetos(id);


--
-- Name: fk_usuario_grupos; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY usuarios_grupos
    ADD CONSTRAINT fk_usuario_grupos FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pagina_grupos; Type: FK CONSTRAINT; Schema: public; Owner: dbmonitora
--

ALTER TABLE ONLY grupos_permissoes
    ADD CONSTRAINT pagina_grupos FOREIGN KEY (pagina_id) REFERENCES paginas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

