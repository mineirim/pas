<?php
class Object{
}
?>
