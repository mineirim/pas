<?php
class trBasetestClass2 {
}
?>
