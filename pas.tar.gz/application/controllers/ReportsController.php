<?php

class ReportsController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    	$this->_helper->layout()->setLayout('layout_report');
    }

    public function indexAction()
    {
        // action body
    }

    public function trimestralAction()
    {
        
        
    }


}



